<?php
/**
 * Bench CMS — configuration
 *
 * Most settings (business details, theme, contact form) live in the admin area.
 * This file only holds server-level options.
 */
return [
    // Leave empty to auto-detect. Set e.g. '/site' if auto-detection gets it wrong.
    'base_path'       => '',

    // Short links: true = /services   false = /index.php?p=services
    // 'auto' (recommended) uses short links once the server is seen handling them,
    // and plain index.php?p= links until then, so the site works on any host.
    // Short links need the included .htaccess (Apache) or the nginx rule in README.md.
    'pretty_urls'     => 'auto',

    // How many previous versions of each content file to keep.
    'backups_to_keep' => 20,

    // Move photos to the trash (Admin → Media → Trash) when the vehicle, page or
    // setting that used them is deleted or changed and nothing else uses them.
    // false = leave them in uploads/ (the behaviour before v1.5).
    'media_trash'     => true,

    // Maximum image upload size in megabytes.
    'max_upload_mb'   => 5,

    // Lock the login for this many minutes after 5 failed attempts.
    'lockout_minutes' => 15,

    // Used for "last saved" times and backups.
    'timezone'        => 'Europe/London',

    // Session cookie name for the admin area.
    'session_name'    => 'bench_admin',

    // Admin → Security warns when PHP is older than the fix for a known critical bug.
    // If your host confirms they've installed a backported fix (common on Ubuntu,
    // Debian, AlmaLinux and CloudLinux, where the version number doesn't change),
    // list the warning's id here to hide it, e.g. ['php2shell'].
    'security_acknowledged' => [],
];
