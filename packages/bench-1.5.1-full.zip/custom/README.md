# custom/ — this site's own changes

Bench updates (Admin → Updates) replace the files Bench ships, but **never touch this folder**,
`content/`, `uploads/` or `config.php`. Put anything specific to this site here and it survives every update.

## Change a theme file

Copy the file from `themes/<theme>/` to the same place under `custom/themes/<theme>/` and edit the copy.
Bench uses your copy instead of the built-in one. For example, to change the Trade theme's footer:

    themes/trade/layout.php  →  custom/themes/trade/layout.php

This works for `layout.php`, `blocks/*.php`, `templates/*.php` (e.g. `cars-detail.php`) and anything in `assets/`.
Copy only the files you change, so everything else keeps getting fixes.

After an update, compare your copies with the new built-in versions (Admin → Updates lists what changed).

## Small CSS tweaks

Create `custom/custom.css`. It loads after the theme's stylesheet on every page, so its rules win.

## A whole new theme

Make `custom/themes/<name>/` with a `theme.json`, `layout.php` and `assets/style.css` (copy a built-in theme to start).
It appears in Admin → Settings → Theme.

## Site-only plugins

Plugins Bench doesn't ship (anything in `plugins/` other than the built-in ones) are also left alone by updates.

PHP files in this folder can't be opened directly over the web (they're blocked in `.htaccess`).
